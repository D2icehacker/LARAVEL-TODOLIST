<?php

namespace App\Http\Controllers;

use App\Models\Todo;
use Illuminate\Http\Request;

class TodoController extends Controller
{
    public function index()
    {
        $todos = Todo::all();
        return view('todos.index', compact('todos'));
    }

    public function store(Request $request)
    {
        // Validate the request data
        $request->validate([
            'title' => 'required',
            // additional validation rules
        ]);

        // Create a new todo
        Todo::create([
            'title' => $request->input('title'),
            // additional todo attributes
        ]);

        return redirect()->route('todos.index');
    }

    public function update(Request $request, Todo $todo)
    {
        // Validate the request data
        $request->validate([
            'title' => 'required',
            // additional validation rules
        ]);

        // Update the todo
        $todo->update([
            'title' => $request->input('title'),
            // additional todo attributes
        ]);

        return redirect()->route('todos.index');
    }

    public function destroy(Todo $todo)
    {
        $todo->delete();
        return redirect()->route('todos.index');
    }
}
