<!-- ! press tab -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Handlee|Rock+Salt&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="style.css">

  <title>To do List</title>

</head>

<body>
  <?php
      // initialize errors variable
    $errors = "";

    // connect to database
    $db = mysqli_connect("localhost", "root", "", "todo");

    // insert a quote if submit button is clicked
    if (isset($_POST['submit'])) {
      if (empty($_POST['task'])) {
        $errors = "*You must fill in the task";
      }else{
        $task = $_POST['task'];
        $sql = "INSERT INTO tasks (task) VALUES ('$task')";
        mysqli_query($db, $sql);
        header('location: welcome.blade.php');
      }
    }
    if (isset($_GET['del_task'])) {
  $id = $_GET['del_task'];

  mysqli_query($db, "DELETE FROM tasks WHERE id=".$id);
  header('location: welcome.blade.php');
}

?>
  <!-- h1>Lorem5 press tab -->
  <div class="container">

  <div class="row justify-content-center">

  <ul>
      <li>

          <div class="content">

            <p class="title"><b>TO DO LIST:</b></p>

            <form method="post" action="welcome.blade.php" class="input_form">
              <?php if (isset($errors)) { ?>
          	<p><?php echo $errors; ?></p>
          <?php } ?>

          		<input type="text" name="task" class="task_input">
          		<button type="submit" name="submit" id="add_btn" class="add_btn">Add Task</button>

          	</form><p style="font-size:10px;color:red;">*Click Task name to mark it done.</p>
            <center>
            <table>
            	<thead>
            		<tr>
            			<th>No.</th>
            			<th>Tasks</th>
            			<th style="width: 60px;">Action</th>
            		</tr>
            	</thead>

            	<tbody>
            		<?php
            		// select all tasks if page is visited or refreshed
            		$tasks = mysqli_query($db, "SELECT * FROM tasks");

            		$i = 1; while ($row = mysqli_fetch_array($tasks)) { ?>
            			<tr>
            				<td class="number" width="10"> <?php echo $i; ?> </td>
            				<td class="task"> <?php echo $row['task']; ?> </td>
            				<td class="action">
            					<a href="welcome.blade.php?del_task=<?php echo $row['id'] ?>" >Remove</a>
            				</td>
            			</tr>
            		<?php $i++; } ?>
            	</tbody>
            </table></center>

            </div>
          </div>
      </li>
    </ul>
</div>
</div>
<script>

// Add a "checked" symbol when clicking on a list item
$(function(){
  var $curParent, Content;
  $(document).delegate("td.task","click", function(){
    if($(this).closest("s").length) {
      Content = $(this).parent("s").html();
      $curParent = $(this).closest("s");
      $(Content).insertAfter($curParent);
      $(this).closest("s").remove();
    }
    else {
      $(this).wrapAll("<s />");
    }
  });
});


</script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style>

*{
	margin:0;
	padding:0;
}
body{
	font-family:arial,sans-serif;
	font-size:100%;
	margin:1em;
	background:#404040;
	color:#fff;
}
.title{
	font-family: 'Rock Salt', cursive;

}
h2,p{
	font-size:100%;
	font-weight:normal;
}
ul,li{
	list-style:none;
}
ul{
	overflow:hidden;
	padding:3em;
}
ul li div.content{
	text-decoration:none;
	color:#000;
	background:#ffc ;
	display:block;
	height:100%;
	width:40em;
	padding:5em;
	-moz-box-shadow:5px 5px 7px rgba(33,33,33,1);
	-webkit-box-shadow: 5px 5px 7px rgba(33,33,33,.7);
	box-shadow: 5px 5px 7px rgba(33,33,33,.7);
	-moz-transition:-moz-transform .15s linear;
	-o-transition:-o-transform .15s linear;
	-webkit-transition:-webkit-transform .15s linear;
}
ul li{
	margin:1em;
	float:left;
}
ul li h2{
	font-size:140%;
	font-weight:bold;
	padding-bottom:10px;
}
ul li p{
	font-family:"Reenie Beanie",arial,sans-serif;
	font-size:100%;
}
ul li div.content{
	-webkit-transform: rotate(-6deg);
	-o-transform: rotate(-6deg);
	-moz-transform:rotate(-6deg);
}

ul li div.content:hover,ul li div.content:focus{
	box-shadow:10px 10px 7px rgba(0,0,0,.7);
	-moz-box-shadow:10px 10px 7px rgba(0,0,0,.7);
	-webkit-box-shadow: 10px 10px 7px rgba(0,0,0,.7);
	-webkit-transform: scale(1.25);
	-moz-transform: scale(1.25);
	-o-transform: scale(1.25);
	position:relative;
	z-index:5;
}
ol{text-align:center;}
ol li{display:inline;padding-right:1em;}
ol li div.content{color:#fff;}

form {
	width: 90%;
	margin: 30px auto;
	border-radius: 5px;
	padding: 10px;
	border: 1px solid black;
	font-size: 10px;

}
form p {
	color: red;
	margin: 0px;
	font-size: 10px;
}
.task_input {
	width: 75%;
	height: 30px;
	padding: 2px 20px;
	border: 2px solid black;
	font-family: 'Handlee', cursive;
	background:#ffc ;
  font-size: 16px;

}
.add_btn {
	height: 30px;
	background: #404040 ;
	color: 	white;
	padding: 5px 20px;
	border-style: none;
	border-radius: 10px;
}

table {
	width:80%;
}


/* Style the list items */
td {
	cursor: pointer;
	position: relative;
	padding: 1px 8px 1px 8px;
	list-style-type: none;
	font-size: 12px;
	transition: 0.2s;
	text-align: left;


	/* make the list items unselectable */
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
}


/* Set all odd list items to a different color (zebra-stripes) */
 td.task:nth-child(odd) {
	 color: red;
	 border-style: hidden;
	 font-family: 'Handlee', cursive;

}

/* Darker background-color on hover */
td:hover {
	background:#ffc ;
}

/* When clicked on, add a background color and strike out text */
td.checked {
	background: #888;
	color: #fff;
	text-decoration: line-through;
}
a{
	color:red;
}
a:hover{
	color:black;
	background:#ffc ;

}
/* Add a "checked" mark when clicked on */
td.checked::before {
	content: '';
	position: absolute;
	border-color: #fff;
	border-style: solid;
	border-width: 0 2px 2px 0;
	top: 10px;
	left: 16px;
	transform: rotate(45deg);
	height: 15px;
	width: 7px;
}

/* Style the close button */
.close {
	position: absolute;
	right: 0;
	top: 0;
	padding: 12px 16px 12px 16px;
}

.close:hover {
	background-color: #f44336;
	color: white;
}
thead{
	text-align: center;
}
td.action{
	color:red;
}
td.task{
	font-family: 'Handlee', cursive;

}
</style>
</html>